class Color:

    def __init__(self, light, dark):
        self.light = light
        self.dark = dark